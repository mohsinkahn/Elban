export default function Dashboard() {
  return (
    <>
      <h1 className="text-2xl font-semibold text-gray-800">Dashboard</h1>
      <p className="text-gray-500 mt-2">Welcome to your dashboard.</p>
    </>
  );
}
